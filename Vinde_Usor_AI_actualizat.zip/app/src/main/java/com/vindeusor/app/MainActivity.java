package com.vindeusor.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.ValueCallback;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.net.Uri;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final String API_URL = "https://script.google.com/macros/s/AKfycbwxfxZuaL79fC-Jdn0dwebMn-pcTavyJpHPb9BI0evWW3wNVC9WGelFXQvR6qZUcLyK/exec";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        webView.addJavascriptInterface(new AiBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, FILE_CHOOSER_REQUEST); }
                catch (Exception e) { fileCallback = null; return false; }
                return true;
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class AiBridge {
        @JavascriptInterface public void postToAi(String payload) {
            new Thread(() -> {
                String response;
                try {
                    response = sendToAppsScript(payload);
                } catch (Exception e) {
                    try {
                        response = new JSONObject()
                            .put("ok", false)
                            .put("error", "Conexiune eșuată: " + e.getMessage())
                            .toString();
                    } catch (Exception ignored) {
                        response = "{\"ok\":false,\"error\":\"Conexiune eșuată.\"}";
                    }
                }
                final String result = response;
                runOnUiThread(() -> webView.evaluateJavascript(
                    "window.onAiResponse(" + JSONObject.quote(result) + ")", null));
            }).start();
        }
    }

    // Apps Script ContentService can redirect the POST response to a temporary
    // googleusercontent URL. Read that redirect with GET to obtain the JSON body.
    private String sendToAppsScript(String payload) throws Exception {
        URL endpoint = new URL(API_URL);
        HttpURLConnection post = (HttpURLConnection) endpoint.openConnection();
        post.setInstanceFollowRedirects(false);
        post.setRequestMethod("POST");
        post.setConnectTimeout(30000);
        post.setReadTimeout(90000);
        post.setDoOutput(true);
        post.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        post.setRequestProperty("Accept", "application/json");
        byte[] bytes = payload.getBytes("UTF-8");
        post.setFixedLengthStreamingMode(bytes.length);
        try (OutputStream os = post.getOutputStream()) { os.write(bytes); }

        int code = post.getResponseCode();
        if (code == HttpURLConnection.HTTP_MOVED_PERM
                || code == HttpURLConnection.HTTP_MOVED_TEMP
                || code == HttpURLConnection.HTTP_SEE_OTHER
                || code == 307 || code == 308) {
            String location = post.getHeaderField("Location");
            post.disconnect();
            if (location == null || location.trim().isEmpty()) {
                throw new Exception("Serverul Apps Script a redirecționat cererea fără o adresă de răspuns.");
            }
            URL redirectedUrl = new URL(endpoint, location);
            HttpURLConnection redirected = (HttpURLConnection) redirectedUrl.openConnection();
            redirected.setInstanceFollowRedirects(true);
            redirected.setRequestMethod("GET");
            redirected.setConnectTimeout(30000);
            redirected.setReadTimeout(90000);
            redirected.setRequestProperty("Accept", "application/json");
            return readResponse(redirected);
        }
        return readResponse(post);
    }

    private String readResponse(HttpURLConnection conn) throws Exception {
        try {
            int code = conn.getResponseCode();
            InputStream is = (code >= 200 && code < 400)
                ? conn.getInputStream() : conn.getErrorStream();
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            if (is != null) {
                try (InputStream input = is) {
                    byte[] buffer = new byte[4096];
                    int n;
                    while ((n = input.read(buffer)) != -1) bos.write(buffer, 0, n);
                }
            }
            String body = bos.toString("UTF-8");
            if (body == null || body.trim().isEmpty()) {
                throw new Exception("Serverul a returnat un răspuns gol (HTTP " + code + "). Verifică implementarea Apps Script.");
            }
            return body;
        } finally {
            conn.disconnect();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && fileCallback != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
