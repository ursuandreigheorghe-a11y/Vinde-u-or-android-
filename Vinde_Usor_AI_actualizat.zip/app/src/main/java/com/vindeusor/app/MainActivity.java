
package com.vindeusor.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.ValueCallback;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.net.Uri;
import android.content.ActivityNotFoundException;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.InputType;
import android.util.TypedValue;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.GoogleAuthProvider;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.api.ApiException;

import org.json.JSONObject;

import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {

    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private FirebaseAuth auth;

    private EditText emailInput;
    private EditText passwordInput;
    private TextView loginStatus;

    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int GOOGLE_SIGN_IN_REQUEST = 1002;

    private static final String API_URL =
        "https://script.google.com/macros/s/AKfycbwxfxZuaL79fC-Jdn0dwebMn-pcTavyJpHPb9BI0evWW3wNVC9WGelFXQvR6qZUcLyK/exec";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        auth = FirebaseAuth.getInstance();

        if (auth.getCurrentUser() != null) {
            showWebApp();
        } else {
            showLoginScreen();
        }
    }

    private int dp(float value) {
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            getResources().getDisplayMetrics()
        );
    }

    private void showLoginScreen() {

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));
        root.setBackgroundColor(Color.WHITE);

        TextView title = new TextView(this);
        title.setText("Vinde Ușor 🤖");
        title.setTextSize(29);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(Color.rgb(17, 24, 39));
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Conectează-te pentru a crea anunțuri cu AI.");
        subtitle.setTextSize(15);
        subtitle.setTextColor(Color.DKGRAY);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, dp(8), 0, dp(22));
        root.addView(subtitle);

        emailInput = new EditText(this);
        emailInput.setSingleLine(true);
        emailInput.setHint("Adresa de e-mail");
        emailInput.setInputType(
            InputType.TYPE_CLASS_TEXT |
            InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        );
        root.addView(emailInput, matchWidth());

        passwordInput = new EditText(this);
        passwordInput.setSingleLine(true);
        passwordInput.setHint("Parola");
        passwordInput.setInputType(
            InputType.TYPE_CLASS_TEXT |
            InputType.TYPE_TEXT_VARIATION_PASSWORD
        );

        LinearLayout.LayoutParams passwordParams = matchWidth();
        passwordParams.topMargin = dp(10);
        root.addView(passwordInput, passwordParams);

        Button loginButton = makeButton("Conectare");
        root.addView(loginButton, buttonParams());
        loginButton.setOnClickListener(v -> signInWithEmail());

        Button registerButton = makeButton("Creează cont nou");
        registerButton.setBackgroundColor(Color.rgb(75, 85, 99));
        root.addView(registerButton, buttonParams());
        registerButton.setOnClickListener(v -> registerWithEmail());

        Button googleButton = makeButton("Continuă cu Google");
        googleButton.setBackgroundColor(Color.rgb(37, 99, 235));
        root.addView(googleButton, buttonParams());
        googleButton.setOnClickListener(v -> signInWithGoogle());

        loginStatus = new TextView(this);
        loginStatus.setText("");
        loginStatus.setTextColor(Color.rgb(185, 28, 28));
        loginStatus.setTextSize(14);
        loginStatus.setGravity(Gravity.CENTER);
        loginStatus.setPadding(0, dp(16), 0, 0);
        root.addView(loginStatus, matchWidth());

        setContentView(root);
    }

    private LinearLayout.LayoutParams matchWidth() {
        return new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams params = matchWidth();
        params.topMargin = dp(10);
        return params;
    }

    private Button makeButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTextSize(15);
        button.setAllCaps(false);
        button.setBackgroundColor(Color.rgb(17, 24, 39));
        return button;
    }

    private void setLoginMessage(String message) {
        if (loginStatus != null) {
            loginStatus.setText(message);
        }
    }

    private void signInWithEmail() {

        String email = emailInput.getText().toString().trim();
        String password = passwordInput.getText().toString();

        if (email.isEmpty() || password.isEmpty()) {
            setLoginMessage("Completează e-mailul și parola.");
            return;
        }

        setLoginMessage("Se verifică datele...");

        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this, task -> {

                if (task.isSuccessful()) {
                    showWebApp();
                } else {
                    setLoginMessage(
                        "Conectarea a eșuat: " +
                        (task.getException() != null
                            ? task.getException().getMessage()
                            : "Încearcă din nou.")
                    );
                }
            });
    }

    private void registerWithEmail() {

        String email = emailInput.getText().toString().trim();
        String password = passwordInput.getText().toString();

        if (email.isEmpty() || password.isEmpty()) {
            setLoginMessage("Completează e-mailul și parola.");
            return;
        }

        if (password.length() < 6) {
            setLoginMessage("Parola trebuie să aibă minimum 6 caractere.");
            return;
        }

        setLoginMessage("Se creează contul...");

        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this, task -> {

                if (task.isSuccessful()) {
                    showWebApp();
                } else {
                    setLoginMessage(
                        "Nu am putut crea contul: " +
                        (task.getException() != null
                            ? task.getException().getMessage()
                            : "Încearcă din nou.")
                    );
                }
            });
    }

    private void signInWithGoogle() {

        try {
            setLoginMessage("Se deschide conectarea Google...");

            GoogleSignInOptions options =
                new GoogleSignInOptions.Builder(
                    GoogleSignInOptions.DEFAULT_SIGN_IN
                )
                .requestIdToken(
                    getString(R.string.default_web_client_id)
                )
                .requestEmail()
                .build();

            Intent intent = GoogleSignIn
                .getClient(this, options)
                .getSignInIntent();

            startActivityForResult(
                intent,
                GOOGLE_SIGN_IN_REQUEST
            );

        } catch (Exception e) {
            setLoginMessage(
                "Eroare la pornirea conectării Google: " +
                e.getClass().getSimpleName() + ": " + e.getMessage()
            );
        }
    }

    private void handleGoogleResult(Intent data) {

        try {
            GoogleSignInAccount account =
                GoogleSignIn.getSignedInAccountFromIntent(data)
                    .getResult(ApiException.class);

            if (account == null) {
                setLoginMessage("Google nu a returnat contul.");
                return;
            }

            if (account.getIdToken() == null) {
                setLoginMessage(
                    "Google nu a returnat tokenul. Verifică OAuth Client ID."
                );
                return;
            }

            AuthCredential credential =
                GoogleAuthProvider.getCredential(
                    account.getIdToken(),
                    null
                );

            setLoginMessage("Se conectează contul Google...");

            auth.signInWithCredential(credential)
                .addOnCompleteListener(this, task -> {

                    if (task.isSuccessful()) {
                        showWebApp();
                    } else {
                        String error = task.getException() != null
                            ? task.getException().getMessage()
                            : "Eroare necunoscută";

                        setLoginMessage(
                            "Eroare Firebase Google: " + error
                        );
                    }
                });

        } catch (ApiException e) {

            setLoginMessage(
                "Eroare Google. Cod: " + e.getStatusCode() +
                ". Detalii: " + e.getMessage()
            );

        } catch (Exception e) {

            setLoginMessage(
                "Eroare Google: " +
                e.getClass().getSimpleName() + ": " + e.getMessage()
            );
        }
    }

    private void showWebApp() {

        webView = new WebView(this);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        webView.addJavascriptInterface(
            new AiBridge(),
            "AndroidBridge"
        );

        webView.setWebViewClient(new WebViewClient());

        webView.setWebChromeClient(new WebChromeClient() {

            @Override
            public boolean onShowFileChooser(
                WebView view,
                ValueCallback<Uri[]> callback,
                FileChooserParams params
            ) {

                if (fileCallback != null) {
                    fileCallback.onReceiveValue(null);
                }

                fileCallback = callback;

                try {
                    Intent intent = params.createIntent();

                    intent.addFlags(
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    );

                    startActivityForResult(
                        intent,
                        FILE_CHOOSER_REQUEST
                    );

                    return true;

                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    callback.onReceiveValue(null);
                    return false;

                } catch (Exception e) {
                    fileCallback = null;
                    callback.onReceiveValue(null);
                    return false;
                }
            }
        });

        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class AiBridge {

        @JavascriptInterface
        public void postToAi(String payload, String callbackId) {

            FirebaseUser user = auth.getCurrentUser();

            if (user == null) {
                sendJavascriptError(
                    callbackId,
                    "Trebuie să te conectezi înainte de generarea anunțului."
                );
                return;
            }

            user.getIdToken(false).addOnCompleteListener(task -> {

                if (!task.isSuccessful() || task.getResult() == null) {
                    sendJavascriptError(
                        callbackId,
                        "Nu am putut obține tokenul Firebase. Conectează-te din nou."
                    );
                    return;
                }

                String firebaseToken = task.getResult().getToken();

                new Thread(() -> {

                    String response;

                    try {
                        JSONObject request = new JSONObject(payload);
                        request.put("token", firebaseToken);

                        response = sendToAppsScript(request.toString());

                    } catch (Exception e) {

                        try {
                            response = new JSONObject()
                                .put("ok", false)
                                .put("error", "Conexiune eșuată: " + e.getMessage())
                                .toString();

                        } catch (Exception ignored) {
                            response = "{\"ok\":false,\"error\":\"Conexiune eșuată.\"}";
                        }
                    }

                    final String result = response;
                    final String id = callbackId == null ? "" : callbackId;

                    runOnUiThread(() ->
                        sendJavascriptResponse(id, result)
                    );

                }).start();
            });
        }
    }

    private void sendJavascriptError(String callbackId, String error) {
        try {
            String response = new JSONObject()
                .put("ok", false)
                .put("error", error)
                .toString();

            sendJavascriptResponse(callbackId, response);

        } catch (Exception ignored) {
        }
    }

    private void sendJavascriptResponse(
        String callbackId,
        String response
    ) {

        if (webView == null) return;

        String javascript =
            "if(window.onAiResponse){" +
            "window.onAiResponse(" +
            JSONObject.quote(callbackId == null ? "" : callbackId) + "," +
            JSONObject.quote(response) +
            ");}";

        webView.evaluateJavascript(javascript, null);
    }

    private String sendToAppsScript(String payload) throws Exception {

        URL endpoint = new URL(API_URL);

        HttpURLConnection post =
            (HttpURLConnection) endpoint.openConnection();

        post.setInstanceFollowRedirects(false);
        post.setRequestMethod("POST");
        post.setConnectTimeout(30000);
        post.setReadTimeout(90000);
        post.setDoOutput(true);

        post.setRequestProperty(
            "Content-Type",
            "application/json; charset=UTF-8"
        );

        post.setRequestProperty("Accept", "application/json");

        byte[] bytes = payload.getBytes("UTF-8");

        post.setFixedLengthStreamingMode(bytes.length);

        try (OutputStream os = post.getOutputStream()) {
            os.write(bytes);
        }

        int code = post.getResponseCode();

        if (code == 301 || code == 302 || code == 303
                || code == 307 || code == 308) {

            String location = post.getHeaderField("Location");
            post.disconnect();

            if (location == null || location.trim().isEmpty()) {
                throw new Exception("Adresa de redirecționare lipsește.");
            }

            URL redirectedUrl = new URL(endpoint, location);

            HttpURLConnection redirected =
                (HttpURLConnection) redirectedUrl.openConnection();

            redirected.setInstanceFollowRedirects(true);
            redirected.setRequestMethod("GET");
            redirected.setConnectTimeout(30000);
            redirected.setReadTimeout(90000);

            return readResponse(redirected);
        }

        return readResponse(post);
    }

    private String readResponse(HttpURLConnection conn) throws Exception {

        try {

            int code = conn.getResponseCode();

            InputStream is = (code >= 200 && code < 400)
                ? conn.getInputStream()
                : conn.getErrorStream();

            ByteArrayOutputStream bos = new ByteArrayOutputStream();

            if (is != null) {
                try (InputStream input = is) {
                    byte[] buffer = new byte[4096];
                    int n;

                    while ((n = input.read(buffer)) != -1) {
                        bos.write(buffer, 0, n);
                    }
                }
            }

            String body = bos.toString("UTF-8");

            if (body.trim().isEmpty()) {
                throw new Exception(
                    "Serverul a returnat un răspuns gol. HTTP " + code
                );
            }

            return body;

        } finally {
            conn.disconnect();
        }
    }

    @Override
    protected void onActivityResult(
        int requestCode,
        int resultCode,
        Intent data
    ) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == GOOGLE_SIGN_IN_REQUEST) {

            if (data != null) {
                handleGoogleResult(data);
            } else {
                setLoginMessage(
                    "Google nu a returnat date. Cod rezultat Android: " +
                    resultCode
                );
            }

            return;
        }

        if (requestCode == FILE_CHOOSER_REQUEST && fileCallback != null) {

            Uri[] results = null;

            if (resultCode == RESULT_OK && data != null) {
                results = WebChromeClient.FileChooserParams.parseResult(
                    resultCode,
                    data
                );
            }

            fileCallback.onReceiveValue(results);
            fileCallback = null;
        }
    }

    @Override
    protected void onDestroy() {

        if (fileCallback != null) {
            fileCallback.onReceiveValue(null);
            fileCallback = null;
        }

        if (webView != null) {
            webView.destroy();
            webView = null;
        }

        super.onDestroy();
    }

    @Override
    public void onBackPressed() {

        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
