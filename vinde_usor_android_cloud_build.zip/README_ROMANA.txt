VINDE UȘOR — proiect Android cu compilare în cloud

Ce este:
- Proiect Android nativ cu WebView și interfața Vinde Ușor încorporată.
- Include workflow GitHub Actions care compilează APK-ul și îl publică drept artifact.
- Această versiune NU conține AI real; generarea anunțului și prețul sunt demonstrative.

Cum obții APK-ul numai cu telefonul:
1. Descarcă și dezarhivează acest ZIP dacă ai o aplicație de arhivare. Alternativ, în GitHub poți încărca fișierele proiectului prin browser, dar trebuie păstrată structura de directoare.
2. Creează un repository nou pe GitHub, de exemplu vinde-usor-android.
3. Încarcă fișierele și directoarele din ZIP în repository, inclusiv .github/workflows/build-apk.yml. E mai ușor din browser în modul Desktop.
4. Deschide fila Actions. Rulează workflow-ul “Build Vinde Usor APK” (Run workflow) sau așteaptă build-ul pornit de push.
5. La finalul rulării, în pagina workflow-ului, descarcă artifact-ul “Vinde-Usor-APK”. Acesta conține app-debug.apk.
6. Deschide APK-ul pe telefon și urmează pașii Android pentru instalare din surse necunoscute, dacă ți se cere.

Atenție: debug APK-ul este pentru testare personală. Nu distribui cheia API în aplicație. Pentru AI real vom adăuga un backend securizat separat.
