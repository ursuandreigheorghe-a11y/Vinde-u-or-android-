VINDE UȘOR — proiect Android cu AI prin Google Apps Script + Gemini

IMPORTANT: acest proiect conectează aplicația la URL-ul Apps Script configurat în MainActivity.java și index.html. Dacă creezi o nouă implementare Apps Script, actualizează URL-ul în ambele fișiere.

Pentru folosire:
1. În Google Apps Script, verifică Script Properties: GEMINI_API_KEY și APP_SECRET. Nu trimite nimănui cheia Gemini sau parola.
2. În aplicație, alege o fotografie, selectează starea și limba, apoi introdu APP_SECRET (parola pe care ai creat-o tu în Script Properties).
3. Apasă „Generează anunț cu AI”. Este necesară conexiune la internet și acces Gemini API; pot exista limite de utilizare.
4. Verifică anunțul și prețul înainte de publicare.

APK prin GitHub Actions:
1. Încarcă ÎNTREGUL conținut al acestui ZIP în rădăcina repository-ului GitHub, păstrând directoarele (app, .github) și fișierele Gradle. Nu încărca doar ZIP-ul în repository.
2. Deschide Actions → Build Vinde Usor APK → Run workflow.
3. După ce build-ul se termină cu succes, deschide rularea și descarcă artifact-ul Vinde-Usor-APK. În el se află app-debug.apk.

Notă de securitate: aplicația trimite fotografia și datele introduse către serviciul Apps Script/Gemini. APP_SECRET introdusă în aplicație nu trebuie tratată ca o protecție puternică; un APK poate fi analizat. Pentru uz personal/testare, nu distribui aplicația sau secretul.
