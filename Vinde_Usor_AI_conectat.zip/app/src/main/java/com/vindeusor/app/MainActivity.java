package com.vindeusor.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.ValueCallback;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.net.Uri;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final String API_URL = "https://script.google.com/macros/s/AKfycbzBUh20nBzEStUvPPrHtZTmFVYbPpbX5WlSmVA-eBceWWeOF9lOsnDXIYSm2QS2C1HY/exec";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        webView.addJavascriptInterface(new AiBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, FILE_CHOOSER_REQUEST); }
                catch (Exception e) { fileCallback = null; return false; }
                return true;
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class AiBridge {
        @JavascriptInterface public void postToAi(String payload) {
            new Thread(() -> {
                HttpURLConnection conn = null;
                String response;
                try {
                    URL url = new URL(API_URL);
                    conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setConnectTimeout(30000);
                    conn.setReadTimeout(60000);
                    conn.setDoOutput(true);
                    conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                    byte[] bytes = payload.getBytes("UTF-8");
                    conn.setFixedLengthStreamingMode(bytes.length);
                    try (OutputStream os = conn.getOutputStream()) { os.write(bytes); }
                    int code = conn.getResponseCode();
                    InputStream is = (code >= 200 && code < 400) ? conn.getInputStream() : conn.getErrorStream();
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    if (is != null) { byte[] buffer = new byte[4096]; int n; while ((n = is.read(buffer)) != -1) bos.write(buffer, 0, n); is.close(); }
                    response = bos.toString("UTF-8");
                    // Apps Script may redirect POST requests. A clear error is preferable to a silent demo.
                    if (response == null || response.trim().isEmpty()) response = "{\"ok\":false,\"error\":\"Serverul a returnat un răspuns gol. Verifică URL-ul și implementarea Apps Script.\"}";
                } catch (Exception e) {
                    try { response = new JSONObject().put("ok", false).put("error", "Conexiune eșuată: " + e.getMessage()).toString(); }
                    catch (Exception ignored) { response = "{\"ok\":false,\"error\":\"Conexiune eșuată.\"}"; }
                } finally { if (conn != null) conn.disconnect(); }
                final String result = response;
                runOnUiThread(() -> webView.evaluateJavascript("window.onAiResponse(" + JSONObject.quote(result) + ")", null));
            }).start();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && fileCallback != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        }
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}